#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define MAX 100

// Function to remove left-factoring
void removeLeftFactoring(char nonTerminal, char commonPrefix[], char suffixes[][MAX], int suffixCount, char nonFactored[][MAX], int nonFactoredCount)
{
    printf("Left Factoring Grammar detected!\n");

    // New Non-Terminal for the factored rules, appending `'` to the non-terminal
    char newNonTerminal[MAX];
    sprintf(newNonTerminal, "%c'", nonTerminal);

    // Print the modified production rule after factoring
    printf("The modified grammar is:\n");
    printf("%c --> %s%s", nonTerminal, commonPrefix, newNonTerminal);

    if (nonFactoredCount > 0)
    {
        printf(" |");
        for (int i = 0; i < nonFactoredCount; i++)
        {
            printf(" %s", nonFactored[i]);
            if (i < nonFactoredCount - 1)
            {
                printf(" |");
            }
        }
    }
    printf("\n");

    printf("%s -->", newNonTerminal);
    for (int i = 0; i < suffixCount; i++)
    {
        printf(" %s", suffixes[i][0] == '\0' ? "e" : suffixes[i]); // Handle epsilon for empty suffix
        if (i < suffixCount - 1)
        {
            printf(" |");
        }
    }
    printf("\n");
}

int main()
{
    char input[MAX], nonTerminal, production[MAX], productionCopy[MAX];
    char nonFactored[MAX][MAX], suffixes[MAX][MAX];
    int nonFactoredCount = 0, suffixCount = 0;

    // Take the production rule as input
    printf("Enter the production rule (e.g., A-->abc|abx|b): ");
    fgets(input, MAX, stdin);
    input[strcspn(input, "\n")] = '\0'; // Remove trailing newline character

    // Extract the non-terminal and the production part
    sscanf(input, "%c-->%s", &nonTerminal, production);
    strcpy(productionCopy, production); // Copy of production for later use

    // Validate the input
    if (!isupper(nonTerminal))
    {
        printf("Invalid non-terminal. It should be an uppercase letter.\n");
        return 1;
    }

    // Split the production into tokens separated by '|'
    char *token = strtok(production, "|");
    char commonPrefix[MAX] = "";
    int firstRun = 1;

    // Find the common prefix across all tokens
    while (token != NULL)
    {
        if (firstRun)
        {
            strcpy(commonPrefix, token);
            firstRun = 0;
        }
        else
        {
            int i = 0;
            // Find the common prefix between the existing commonPrefix and the current token
            while (commonPrefix[i] == token[i] && commonPrefix[i] != '\0' && token[i] != '\0')
            {
                i++;
            }
            commonPrefix[i] = '\0'; // Adjust the common prefix to the new shorter prefix
        }

        token = strtok(NULL, "|");
    }

    // If no common prefix is found, there's no left-factoring
    if (strlen(commonPrefix) == 0 || strlen(commonPrefix) == 1)
    {
        printf("No Left Factoring present.\n");
        return 0;
    }

    // Split the production again to separate factored and non-factored parts
    token = strtok(productionCopy, "|");
    while (token != NULL)
    {
        if (strncmp(token, commonPrefix, strlen(commonPrefix)) == 0)
        {
            // Store the suffix (part after the common prefix)
            strcpy(suffixes[suffixCount++], token + strlen(commonPrefix));
        }
        else
        {
            // Store non-factored productions
            strcpy(nonFactored[nonFactoredCount++], token);
        }
        token = strtok(NULL, "|");
    }

    // Remove left factoring
    removeLeftFactoring(nonTerminal, commonPrefix, suffixes, suffixCount, nonFactored, nonFactoredCount);

    return 0;
}